<?php
require("header.php");
require("config.php");

// section 1 code goes here!




// Section 4b code goes here!





// Section 2a code goes here!	







// Section 2b code is provided for you here!	
	$result = mysqli_query($db, $sql);

// Section 2c code is provided for you here!		
	$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
	echo "<h2 id='title'>" . $row['subject'] . "</h2><br />";
	echo "<p id='byline'>In <a href='viewcat.php?id=" . $row['cat_id'] ."'>" . $row	['cat'] ."</a> - Posted on <span class='datetime'>" . date("D jS F Y g.iA", strtotime($row	['dateposted'])) ."</span>";

	if(isset($_SESSION['USERNAME']) == TRUE) {
		echo "<span id='edit'><a href='updateentry.php?id=" . $row['id'] . "'>edit</a></span>";
	}
	
	echo "</p>";

	echo "<p id='entrybody'>";
	echo nl2br($row['body']);
	echo "</p>";
	
// Section 3a code is provided for you here!		
	echo "<div id='comments'>";
	$commsql = "SELECT * FROM comments WHERE blog_id = " . $validentry . " ORDER BY dateposted DESC;";
	$commresult = mysqli_query($db, $commsql);
	$numrows_comm = mysqli_num_rows($commresult);
	
// Section 3b code is provided for you here!		
	if($numrows_comm == 0) {
		echo "<p>No comments.</p>";
	}
	else {
		$i = 1;

		while($commrow = mysqli_fetch_array($commresult, MYSQLI_ASSOC)) {
			echo "<a name='comment" . $i . "'></a>\n";
			echo "<p class='commenthead'>Comment by " . $commrow['name'] . " on " . date("D jS F Y g.iA", strtotime($commrow['dateposted'])) . "</p>\n";
			echo "<p class='commentbody'>".$commrow['comment']."</p>\n";
			$i++;		
		}
	}
	echo "</div>\n";
	
// Section 4a code goes here!		
?>
<div id='addcomment'>
<h3>Leave a comment</h3>



      // enter form here (4a)





</div>

// Section 4c code goes here!	Code to include the footer!
<?php
}



?>
