  <br /><br />
  <hr />
  <p>Copyright &copy;2017 Riskyjobs<br />
  Web site designed by {Your name here}</p>
</body>
</html>
